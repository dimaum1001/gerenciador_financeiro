from typing import List, Optional
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, desc, func, extract

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.budget import Budget
from app.models.category import Category
from app.models.transaction import Transaction
from app.schemas.budget import BudgetCreate, BudgetUpdate, BudgetResponse, BudgetListResponse

router = APIRouter()

@router.get("/", response_model=BudgetListResponse)
async def list_budgets(
    skip: int = 0,
    limit: int = 100,
    categoria_id: Optional[str] = None,
    year: Optional[int] = None,
    month: Optional[int] = None,
    status: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar orçamentos do usuário com filtros opcionais"""
    query = db.query(Budget).options(
        joinedload(Budget.categoria)
    ).filter(Budget.user_id == current_user.id)
    
    # Aplicar filtros
    if categoria_id:
        query = query.filter(Budget.categoria_id == categoria_id)
    
    if year:
        query = query.filter(Budget.ano == year)
    
    if month:
        query = query.filter(Budget.mes == month)
    
    if status:
        # Calcular status baseado no gasto atual vs planejado
        # Isso seria melhor implementado como uma view ou computed field
        pass
    
    # Contar total
    total = query.count()
    
    # Aplicar paginação e ordenação
    budgets = query.order_by(desc(Budget.ano), desc(Budget.mes), Budget.categoria_id).offset(skip).limit(limit).all()
    
    # Calcular gastos realizados para cada orçamento
    for budget in budgets:
        gasto_realizado = db.query(func.sum(Transaction.valor)).filter(
            and_(
                Transaction.user_id == current_user.id,
                Transaction.categoria_id == budget.categoria_id,
                Transaction.tipo == 'expense',
                extract('year', Transaction.data) == budget.ano,
                extract('month', Transaction.data) == budget.mes
            )
        ).scalar() or 0
        
        budget.gasto_realizado = float(abs(gasto_realizado))
        budget.percentual_utilizado = (budget.gasto_realizado / budget.valor_planejado * 100) if budget.valor_planejado > 0 else 0
        
        # Determinar status
        if budget.percentual_utilizado >= 100:
            budget.status_calculado = 'exceeded'
        elif budget.percentual_utilizado >= 80:
            budget.status_calculado = 'warning'
        else:
            budget.status_calculado = 'good'
    
    return BudgetListResponse(
        budgets=budgets,
        total=total,
        skip=skip,
        limit=limit
    )

@router.post("/", response_model=BudgetResponse, status_code=status.HTTP_201_CREATED)
async def create_budget(
    budget_data: BudgetCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Criar novo orçamento"""
    # Verificar se categoria existe
    categoria = db.query(Category).filter(
        and_(
            Category.id == budget_data.categoria_id,
            Category.user_id == current_user.id
        )
    ).first()
    
    if not categoria:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Categoria não encontrada"
        )
    
    # Verificar se já existe orçamento para esta categoria no período
    existing = db.query(Budget).filter(
        and_(
            Budget.user_id == current_user.id,
            Budget.categoria_id == budget_data.categoria_id,
            Budget.ano == budget_data.ano,
            Budget.mes == budget_data.mes
        )
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Já existe um orçamento para esta categoria no período especificado"
        )
    
    # Criar orçamento
    budget = Budget(
        **budget_data.model_dump(),
        user_id=current_user.id
    )
    
    db.add(budget)
    db.commit()
    db.refresh(budget)
    
    return budget

@router.get("/{budget_id}", response_model=BudgetResponse)
async def get_budget(
    budget_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter orçamento específico"""
    budget = db.query(Budget).options(
        joinedload(Budget.categoria)
    ).filter(
        and_(
            Budget.id == budget_id,
            Budget.user_id == current_user.id
        )
    ).first()
    
    if not budget:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Orçamento não encontrado"
        )
    
    # Calcular gasto realizado
    gasto_realizado = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.categoria_id == budget.categoria_id,
            Transaction.tipo == 'expense',
            extract('year', Transaction.data) == budget.ano,
            extract('month', Transaction.data) == budget.mes
        )
    ).scalar() or 0
    
    budget.gasto_realizado = float(abs(gasto_realizado))
    budget.percentual_utilizado = (budget.gasto_realizado / budget.valor_planejado * 100) if budget.valor_planejado > 0 else 0
    
    return budget

@router.put("/{budget_id}", response_model=BudgetResponse)
async def update_budget(
    budget_id: str,
    budget_data: BudgetUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Atualizar orçamento"""
    budget = db.query(Budget).filter(
        and_(
            Budget.id == budget_id,
            Budget.user_id == current_user.id
        )
    ).first()
    
    if not budget:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Orçamento não encontrado"
        )
    
    # Atualizar campos
    update_data = budget_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(budget, field, value)
    
    db.commit()
    db.refresh(budget)
    
    return budget

@router.delete("/{budget_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_budget(
    budget_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Excluir orçamento"""
    budget = db.query(Budget).filter(
        and_(
            Budget.id == budget_id,
            Budget.user_id == current_user.id
        )
    ).first()
    
    if not budget:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Orçamento não encontrado"
        )
    
    db.delete(budget)
    db.commit()

@router.get("/summary/{year}/{month}")
async def get_budget_summary(
    year: int,
    month: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter resumo de orçamentos para um período"""
    # Buscar todos os orçamentos do período
    budgets = db.query(Budget).options(
        joinedload(Budget.categoria)
    ).filter(
        and_(
            Budget.user_id == current_user.id,
            Budget.ano == year,
            Budget.mes == month
        )
    ).all()
    
    total_planejado = 0
    total_realizado = 0
    orcamentos_detalhados = []
    
    for budget in budgets:
        # Calcular gasto realizado
        gasto_realizado = db.query(func.sum(Transaction.valor)).filter(
            and_(
                Transaction.user_id == current_user.id,
                Transaction.categoria_id == budget.categoria_id,
                Transaction.tipo == 'expense',
                extract('year', Transaction.data) == year,
                extract('month', Transaction.data) == month
            )
        ).scalar() or 0
        
        gasto_realizado = float(abs(gasto_realizado))
        percentual = (gasto_realizado / budget.valor_planejado * 100) if budget.valor_planejado > 0 else 0
        
        # Determinar status
        if percentual >= 100:
            status = 'exceeded'
        elif percentual >= 80:
            status = 'warning'
        else:
            status = 'good'
        
        orcamentos_detalhados.append({
            "id": str(budget.id),
            "categoria": budget.categoria.nome,
            "categoria_cor": budget.categoria.cor,
            "valor_planejado": budget.valor_planejado,
            "gasto_realizado": gasto_realizado,
            "percentual_utilizado": percentual,
            "valor_restante": budget.valor_planejado - gasto_realizado,
            "status": status
        })
        
        total_planejado += budget.valor_planejado
        total_realizado += gasto_realizado
    
    # Calcular estatísticas gerais
    percentual_geral = (total_realizado / total_planejado * 100) if total_planejado > 0 else 0
    
    # Contar status
    status_counts = {
        'good': len([o for o in orcamentos_detalhados if o['status'] == 'good']),
        'warning': len([o for o in orcamentos_detalhados if o['status'] == 'warning']),
        'exceeded': len([o for o in orcamentos_detalhados if o['status'] == 'exceeded'])
    }
    
    return {
        "year": year,
        "month": month,
        "total_planejado": total_planejado,
        "total_realizado": total_realizado,
        "percentual_geral": percentual_geral,
        "valor_restante": total_planejado - total_realizado,
        "status_counts": status_counts,
        "orcamentos": orcamentos_detalhados
    }

@router.post("/copy/{year}/{month}")
async def copy_budgets_from_previous_month(
    year: int,
    month: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Copiar orçamentos do mês anterior"""
    # Calcular mês anterior
    if month == 1:
        prev_year = year - 1
        prev_month = 12
    else:
        prev_year = year
        prev_month = month - 1
    
    # Buscar orçamentos do mês anterior
    prev_budgets = db.query(Budget).filter(
        and_(
            Budget.user_id == current_user.id,
            Budget.ano == prev_year,
            Budget.mes == prev_month
        )
    ).all()
    
    if not prev_budgets:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Nenhum orçamento encontrado no mês anterior"
        )
    
    # Verificar se já existem orçamentos no mês atual
    existing_budgets = db.query(Budget).filter(
        and_(
            Budget.user_id == current_user.id,
            Budget.ano == year,
            Budget.mes == month
        )
    ).count()
    
    if existing_budgets > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Já existem orçamentos para este período"
        )
    
    # Copiar orçamentos
    copied_count = 0
    for prev_budget in prev_budgets:
        new_budget = Budget(
            user_id=current_user.id,
            categoria_id=prev_budget.categoria_id,
            ano=year,
            mes=month,
            valor_planejado=prev_budget.valor_planejado,
            descricao=prev_budget.descricao
        )
        db.add(new_budget)
        copied_count += 1
    
    db.commit()
    
    return {
        "message": f"{copied_count} orçamentos copiados com sucesso",
        "copied_count": copied_count,
        "target_year": year,
        "target_month": month
    }
