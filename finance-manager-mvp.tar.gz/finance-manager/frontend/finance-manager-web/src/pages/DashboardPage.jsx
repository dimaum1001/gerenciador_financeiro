import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  CreditCard,
  PiggyBank,
  Target,
  Calendar,
  ArrowUpRight,
  ArrowDownRight,
  AlertTriangle,
  CheckCircle,
  Clock
} from 'lucide-react'
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts'

// Dados mockados para demonstração
const mockData = {
  cards: [
    {
      title: 'Saldo Total',
      value: 'R$ 49.250,00',
      change: '+8,2%',
      trend: 'up',
      icon: DollarSign,
      color: 'text-green-600'
    },
    {
      title: 'Receitas do Mês',
      value: 'R$ 5.000,00',
      change: '+2,1%',
      trend: 'up',
      icon: TrendingUp,
      color: 'text-blue-600'
    },
    {
      title: 'Despesas do Mês',
      value: 'R$ 3.250,00',
      change: '-5,4%',
      trend: 'down',
      icon: TrendingDown,
      color: 'text-red-600'
    },
    {
      title: 'Economia do Mês',
      value: 'R$ 1.750,00',
      change: '+12,8%',
      trend: 'up',
      icon: PiggyBank,
      color: 'text-green-600'
    }
  ],
  
  fluxoCaixa: [
    { mes: 'Jul', receitas: 4800, despesas: 3200, saldo: 1600 },
    { mes: 'Ago', receitas: 5200, despesas: 3100, saldo: 2100 },
    { mes: 'Set', receitas: 4900, despesas: 3400, saldo: 1500 },
    { mes: 'Out', receitas: 5100, despesas: 3300, saldo: 1800 },
    { mes: 'Nov', receitas: 5300, despesas: 3150, saldo: 2150 },
    { mes: 'Dez', receitas: 5000, despesas: 3250, saldo: 1750 }
  ],
  
  categorias: [
    { nome: 'Alimentação', valor: 850, cor: '#ef4444' },
    { nome: 'Moradia', valor: 1200, cor: '#f97316' },
    { nome: 'Transporte', valor: 380, cor: '#3b82f6' },
    { nome: 'Saúde', valor: 250, cor: '#06b6d4' },
    { nome: 'Lazer', valor: 420, cor: '#8b5cf6' },
    { nome: 'Outros', valor: 150, cor: '#6b7280' }
  ],
  
  contas: [
    { nome: 'Conta Corrente', saldo: 8500, tipo: 'checking', cor: '#3b82f6' },
    { nome: 'Poupança', saldo: 15000, tipo: 'savings', cor: '#059669' },
    { nome: 'Investimentos', saldo: 25000, tipo: 'investment', cor: '#f59e0b' },
    { nome: 'Carteira', saldo: 750, tipo: 'cash', cor: '#10b981' }
  ],
  
  vencimentos: [
    { descricao: 'Cartão Nubank', valor: 1250, vencimento: '2024-01-15', dias: 3, status: 'pending' },
    { descricao: 'Aluguel', valor: 1200, vencimento: '2024-01-10', dias: -2, status: 'overdue' },
    { descricao: 'Internet', valor: 89.90, vencimento: '2024-01-20', dias: 8, status: 'pending' },
    { descricao: 'Energia', valor: 125, vencimento: '2024-01-25', dias: 13, status: 'pending' }
  ],
  
  orcamentos: [
    { categoria: 'Alimentação', planejado: 800, realizado: 650, percentual: 81 },
    { categoria: 'Moradia', planejado: 1500, realizado: 1200, percentual: 80 },
    { categoria: 'Transporte', planejado: 400, realizado: 380, percentual: 95 },
    { categoria: 'Lazer', planejado: 500, realizado: 420, percentual: 84 }
  ]
}

function StatCard({ title, value, change, trend, icon: Icon, color }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center text-xs text-muted-foreground">
          {trend === 'up' ? (
            <ArrowUpRight className="h-3 w-3 text-green-500 mr-1" />
          ) : (
            <ArrowDownRight className="h-3 w-3 text-red-500 mr-1" />
          )}
          <span className={trend === 'up' ? 'text-green-600' : 'text-red-600'}>
            {change}
          </span>
          <span className="ml-1">vs mês anterior</span>
        </div>
      </CardContent>
    </Card>
  )
}

function FluxoCaixaChart() {
  return (
    <Card className="col-span-4">
      <CardHeader>
        <CardTitle>Fluxo de Caixa</CardTitle>
        <CardDescription>
          Receitas vs Despesas dos últimos 6 meses
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={mockData.fluxoCaixa}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="mes" />
            <YAxis />
            <Tooltip 
              formatter={(value) => [`R$ ${value.toLocaleString()}`, '']}
              labelFormatter={(label) => `Mês: ${label}`}
            />
            <Area 
              type="monotone" 
              dataKey="receitas" 
              stackId="1"
              stroke="#10b981" 
              fill="#10b981" 
              fillOpacity={0.6}
              name="Receitas"
            />
            <Area 
              type="monotone" 
              dataKey="despesas" 
              stackId="2"
              stroke="#ef4444" 
              fill="#ef4444" 
              fillOpacity={0.6}
              name="Despesas"
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

function GastosCategoriasChart() {
  return (
    <Card className="col-span-3">
      <CardHeader>
        <CardTitle>Gastos por Categoria</CardTitle>
        <CardDescription>
          Distribuição das despesas do mês atual
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={mockData.categorias}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={100}
              paddingAngle={5}
              dataKey="valor"
            >
              {mockData.categorias.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.cor} />
              ))}
            </Pie>
            <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

function SaldosContas() {
  const total = mockData.contas.reduce((acc, conta) => acc + conta.saldo, 0)
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Saldos por Conta</CardTitle>
        <CardDescription>
          Distribuição do patrimônio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {mockData.contas.map((conta, index) => {
          const percentual = (conta.saldo / total) * 100
          
          return (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: conta.cor }}
                  />
                  <span className="text-sm font-medium">{conta.nome}</span>
                </div>
                <span className="text-sm font-bold">
                  R$ {conta.saldo.toLocaleString()}
                </span>
              </div>
              <Progress value={percentual} className="h-2" />
              <div className="text-xs text-muted-foreground text-right">
                {percentual.toFixed(1)}% do total
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}

function ProximosVencimentos() {
  const getStatusIcon = (status, dias) => {
    if (status === 'overdue' || dias < 0) {
      return <AlertTriangle className="h-4 w-4 text-red-500" />
    } else if (dias <= 3) {
      return <Clock className="h-4 w-4 text-yellow-500" />
    } else {
      return <CheckCircle className="h-4 w-4 text-green-500" />
    }
  }

  const getStatusBadge = (status, dias) => {
    if (status === 'overdue' || dias < 0) {
      return <Badge variant="destructive">Vencido</Badge>
    } else if (dias <= 3) {
      return <Badge variant="secondary">Próximo</Badge>
    } else {
      return <Badge variant="outline">Pendente</Badge>
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Próximos Vencimentos</CardTitle>
        <CardDescription>
          Contas a pagar nos próximos dias
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {mockData.vencimentos.map((item, index) => (
          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(item.status, item.dias)}
              <div>
                <div className="font-medium">{item.descricao}</div>
                <div className="text-sm text-muted-foreground">
                  Vence em {Math.abs(item.dias)} dia{Math.abs(item.dias) !== 1 ? 's' : ''}
                  {item.dias < 0 && ' (atrasado)'}
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="font-bold">R$ {item.valor.toLocaleString()}</div>
              {getStatusBadge(item.status, item.dias)}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}

function OrcamentosResumo() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Orçamentos do Mês</CardTitle>
        <CardDescription>
          Acompanhamento das metas mensais
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {mockData.orcamentos.map((orcamento, index) => {
          const getProgressColor = (percentual) => {
            if (percentual >= 100) return 'bg-red-500'
            if (percentual >= 80) return 'bg-yellow-500'
            return 'bg-green-500'
          }

          return (
            <div key={index} className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{orcamento.categoria}</span>
                <span className="text-sm">
                  R$ {orcamento.realizado} / R$ {orcamento.planejado}
                </span>
              </div>
              <div className="relative">
                <Progress value={orcamento.percentual} className="h-2" />
                <div 
                  className={`absolute top-0 left-0 h-2 rounded-full transition-all ${getProgressColor(orcamento.percentual)}`}
                  style={{ width: `${Math.min(orcamento.percentual, 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{orcamento.percentual}% utilizado</span>
                <span>
                  R$ {(orcamento.planejado - orcamento.realizado).toLocaleString()} restante
                </span>
              </div>
            </div>
          )
        })}
      </CardContent>
    </Card>
  )
}

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Visão geral das suas finanças em tempo real
        </p>
      </div>

      {/* Cards de estatísticas */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {mockData.cards.map((card, index) => (
          <StatCard key={index} {...card} />
        ))}
      </div>

      {/* Gráficos principais */}
      <div className="grid gap-4 md:grid-cols-7">
        <FluxoCaixaChart />
        <GastosCategoriasChart />
      </div>

      {/* Seção inferior */}
      <div className="grid gap-4 md:grid-cols-3">
        <SaldosContas />
        <ProximosVencimentos />
        <OrcamentosResumo />
      </div>
    </div>
  )
}
