from typing import List, Optional
from datetime import datetime, date, timedelta
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc, func, extract, text

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.transaction import Transaction
from app.models.account import Account
from app.models.category import Category
from app.models.budget import Budget
from app.schemas.dashboard import DashboardSummary, MonthlyFlow, CategorySummary

router = APIRouter()

@router.get("/summary", response_model=DashboardSummary)
async def get_dashboard_summary(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter resumo geral do dashboard"""
    now = datetime.now()
    current_month = now.month
    current_year = now.year
    
    # Saldo total de todas as contas
    total_balance = db.query(func.sum(Account.saldo_atual)).filter(
        and_(
            Account.user_id == current_user.id,
            Account.ativo == True
        )
    ).scalar() or 0
    
    # Receitas do mês atual
    monthly_income = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'income',
            extract('year', Transaction.data) == current_year,
            extract('month', Transaction.data) == current_month
        )
    ).scalar() or 0
    
    # Despesas do mês atual
    monthly_expenses = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'expense',
            extract('year', Transaction.data) == current_year,
            extract('month', Transaction.data) == current_month
        )
    ).scalar() or 0
    
    # Economia do mês
    monthly_savings = monthly_income + monthly_expenses  # expenses são negativos
    
    # Comparação com mês anterior
    prev_month = current_month - 1 if current_month > 1 else 12
    prev_year = current_year if current_month > 1 else current_year - 1
    
    prev_income = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'income',
            extract('year', Transaction.data) == prev_year,
            extract('month', Transaction.data) == prev_month
        )
    ).scalar() or 0
    
    prev_expenses = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'expense',
            extract('year', Transaction.data) == prev_year,
            extract('month', Transaction.data) == prev_month
        )
    ).scalar() or 0
    
    # Calcular variações percentuais
    income_change = ((monthly_income - prev_income) / prev_income * 100) if prev_income != 0 else 0
    expenses_change = ((abs(monthly_expenses) - abs(prev_expenses)) / abs(prev_expenses) * 100) if prev_expenses != 0 else 0
    
    return DashboardSummary(
        total_balance=float(total_balance),
        monthly_income=float(monthly_income),
        monthly_expenses=float(abs(monthly_expenses)),
        monthly_savings=float(monthly_savings),
        income_change=float(income_change),
        expenses_change=float(expenses_change),
        current_month=current_month,
        current_year=current_year
    )

@router.get("/cash-flow", response_model=List[MonthlyFlow])
async def get_cash_flow(
    months: int = Query(default=6, ge=1, le=24),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter fluxo de caixa dos últimos N meses"""
    now = datetime.now()
    flows = []
    
    for i in range(months):
        # Calcular mês e ano
        target_date = now - timedelta(days=30 * i)
        month = target_date.month
        year = target_date.year
        
        # Receitas do mês
        income = db.query(func.sum(Transaction.valor)).filter(
            and_(
                Transaction.user_id == current_user.id,
                Transaction.tipo == 'income',
                extract('year', Transaction.data) == year,
                extract('month', Transaction.data) == month
            )
        ).scalar() or 0
        
        # Despesas do mês
        expenses = db.query(func.sum(Transaction.valor)).filter(
            and_(
                Transaction.user_id == current_user.id,
                Transaction.tipo == 'expense',
                extract('year', Transaction.data) == year,
                extract('month', Transaction.data) == month
            )
        ).scalar() or 0
        
        flows.append(MonthlyFlow(
            month=month,
            year=year,
            month_name=target_date.strftime('%b'),
            income=float(income),
            expenses=float(abs(expenses)),
            balance=float(income + expenses)  # expenses são negativos
        ))
    
    return list(reversed(flows))  # Ordem cronológica

@router.get("/categories-summary")
async def get_categories_summary(
    tipo: str = Query(..., regex="^(income|expense)$"),
    months: int = Query(default=1, ge=1, le=12),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter resumo por categorias"""
    now = datetime.now()
    start_date = now - timedelta(days=30 * months)
    
    # Query para somar por categoria
    results = db.query(
        Category.nome.label('name'),
        Category.cor.label('color'),
        func.sum(Transaction.valor).label('total'),
        func.count(Transaction.id).label('count')
    ).join(
        Transaction, Transaction.categoria_id == Category.id
    ).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == tipo,
            Transaction.data >= start_date.date()
        )
    ).group_by(Category.id, Category.nome, Category.cor).all()
    
    # Calcular total geral para percentuais
    total_amount = sum(float(abs(r.total)) for r in results)
    
    categories = []
    for result in results:
        amount = float(abs(result.total))
        percentage = (amount / total_amount * 100) if total_amount > 0 else 0
        
        categories.append({
            "name": result.name,
            "color": result.color,
            "amount": amount,
            "count": result.count,
            "percentage": percentage
        })
    
    # Ordenar por valor decrescente
    categories.sort(key=lambda x: x['amount'], reverse=True)
    
    return categories

@router.get("/accounts-balance")
async def get_accounts_balance(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter saldos de todas as contas"""
    accounts = db.query(Account).filter(
        and_(
            Account.user_id == current_user.id,
            Account.ativo == True
        )
    ).order_by(desc(Account.saldo_atual)).all()
    
    total_balance = sum(acc.saldo_atual for acc in accounts)
    
    return [
        {
            "id": str(acc.id),
            "name": acc.nome,
            "type": acc.tipo,
            "balance": float(acc.saldo_atual),
            "color": acc.cor,
            "percentage": (acc.saldo_atual / total_balance * 100) if total_balance > 0 else 0
        }
        for acc in accounts
    ]

@router.get("/upcoming-bills")
async def get_upcoming_bills(
    days: int = Query(default=30, ge=1, le=90),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter contas a vencer nos próximos N dias"""
    # Esta é uma implementação simplificada
    # Em um sistema real, você teria uma tabela de recorrências ou lembretes
    
    now = datetime.now()
    end_date = now + timedelta(days=days)
    
    # Por enquanto, vamos simular com transações recorrentes
    # que deveriam vencer baseado em padrões históricos
    
    # Buscar despesas recorrentes (mesmo valor, mesma categoria, mesmo dia do mês)
    recurring_expenses = db.query(
        Transaction.descricao,
        Transaction.valor,
        Category.nome.label('categoria'),
        func.extract('day', Transaction.data).label('dia_mes')
    ).join(
        Category, Transaction.categoria_id == Category.id
    ).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'expense',
            Transaction.data >= (now - timedelta(days=90)).date()
        )
    ).group_by(
        Transaction.descricao,
        Transaction.valor,
        Category.nome,
        func.extract('day', Transaction.data)
    ).having(func.count(Transaction.id) >= 2).all()
    
    upcoming = []
    for expense in recurring_expenses:
        # Calcular próxima data de vencimento
        next_month = now.month + 1 if now.month < 12 else 1
        next_year = now.year if now.month < 12 else now.year + 1
        
        try:
            next_date = datetime(next_year, next_month, int(expense.dia_mes))
            days_until = (next_date - now).days
            
            if 0 <= days_until <= days:
                status = 'overdue' if days_until < 0 else 'pending'
                
                upcoming.append({
                    "description": expense.descricao,
                    "amount": float(abs(expense.valor)),
                    "category": expense.categoria,
                    "due_date": next_date.date(),
                    "days_until": days_until,
                    "status": status
                })
        except ValueError:
            # Dia inválido (ex: 31 em fevereiro)
            continue
    
    return sorted(upcoming, key=lambda x: x['days_until'])

@router.get("/budget-status")
async def get_budget_status(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter status dos orçamentos do mês"""
    budgets = db.query(Budget).filter(
        and_(
            Budget.user_id == current_user.id,
            Budget.ano == year,
            Budget.mes == month
        )
    ).all()
    
    if not budgets:
        return {
            "total_planned": 0,
            "total_spent": 0,
            "percentage": 0,
            "status_counts": {"good": 0, "warning": 0, "exceeded": 0},
            "budgets": []
        }
    
    total_planned = 0
    total_spent = 0
    budget_details = []
    status_counts = {"good": 0, "warning": 0, "exceeded": 0}
    
    for budget in budgets:
        # Calcular gasto realizado
        spent = db.query(func.sum(Transaction.valor)).filter(
            and_(
                Transaction.user_id == current_user.id,
                Transaction.categoria_id == budget.categoria_id,
                Transaction.tipo == 'expense',
                extract('year', Transaction.data) == year,
                extract('month', Transaction.data) == month
            )
        ).scalar() or 0
        
        spent = float(abs(spent))
        percentage = (spent / budget.valor_planejado * 100) if budget.valor_planejado > 0 else 0
        
        # Determinar status
        if percentage >= 100:
            status = 'exceeded'
        elif percentage >= 80:
            status = 'warning'
        else:
            status = 'good'
        
        status_counts[status] += 1
        total_planned += budget.valor_planejado
        total_spent += spent
        
        # Buscar categoria
        categoria = db.query(Category).filter(Category.id == budget.categoria_id).first()
        
        budget_details.append({
            "id": str(budget.id),
            "category": categoria.nome if categoria else "Categoria não encontrada",
            "category_color": categoria.cor if categoria else "#gray",
            "planned": budget.valor_planejado,
            "spent": spent,
            "percentage": percentage,
            "remaining": budget.valor_planejado - spent,
            "status": status
        })
    
    overall_percentage = (total_spent / total_planned * 100) if total_planned > 0 else 0
    
    return {
        "total_planned": total_planned,
        "total_spent": total_spent,
        "percentage": overall_percentage,
        "remaining": total_planned - total_spent,
        "status_counts": status_counts,
        "budgets": budget_details
    }
