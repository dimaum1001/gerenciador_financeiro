import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { 
  Plus, 
  Search, 
  Filter, 
  Download, 
  Upload,
  ArrowUpDown,
  Calendar,
  DollarSign,
  Tag
} from 'lucide-react'

// Dados mockados
const mockTransactions = [
  {
    id: 1,
    data: '2024-01-12',
    descricao: 'Supermercado Extra',
    categoria: 'Alimentação',
    conta: 'Cartão Nubank',
    valor: -185.50,
    status: 'cleared',
    tipo: 'expense'
  },
  {
    id: 2,
    data: '2024-01-10',
    descricao: 'Salário Janeiro',
    categoria: 'Salário',
    conta: 'Conta Corrente',
    valor: 5000.00,
    status: 'cleared',
    tipo: 'income'
  },
  {
    id: 3,
    data: '2024-01-08',
    descricao: 'Uber para trabalho',
    categoria: 'Transporte',
    conta: 'Cartão Nubank',
    valor: -25.80,
    status: 'pending',
    tipo: 'expense'
  },
  {
    id: 4,
    data: '2024-01-05',
    descricao: 'Freelance Website',
    categoria: 'Freelance',
    conta: 'Conta Corrente',
    valor: 1200.00,
    status: 'cleared',
    tipo: 'income'
  },
  {
    id: 5,
    data: '2024-01-03',
    descricao: 'Aluguel Janeiro',
    categoria: 'Moradia',
    conta: 'Conta Corrente',
    valor: -1200.00,
    status: 'cleared',
    tipo: 'expense'
  }
]

function TransactionRow({ transaction }) {
  const getStatusBadge = (status) => {
    const variants = {
      cleared: 'default',
      pending: 'secondary',
      reconciled: 'outline'
    }
    
    const labels = {
      cleared: 'Confirmado',
      pending: 'Pendente',
      reconciled: 'Conciliado'
    }
    
    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    )
  }

  const getValueColor = (valor, tipo) => {
    if (tipo === 'income') return 'text-green-600'
    if (tipo === 'expense') return 'text-red-600'
    return 'text-muted-foreground'
  }

  return (
    <div className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors">
      <div className="flex items-center gap-4">
        <div className={`p-2 rounded-lg ${
          transaction.tipo === 'income' 
            ? 'bg-green-100 text-green-600' 
            : 'bg-red-100 text-red-600'
        }`}>
          <ArrowUpDown className="h-4 w-4" />
        </div>
        
        <div>
          <div className="font-medium">{transaction.descricao}</div>
          <div className="text-sm text-muted-foreground">
            {transaction.categoria} • {transaction.conta}
          </div>
        </div>
      </div>
      
      <div className="text-right">
        <div className={`font-bold ${getValueColor(transaction.valor, transaction.tipo)}`}>
          {transaction.valor > 0 ? '+' : ''}R$ {Math.abs(transaction.valor).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
        </div>
        <div className="text-sm text-muted-foreground">
          {new Date(transaction.data).toLocaleDateString('pt-BR')}
        </div>
      </div>
      
      <div className="ml-4">
        {getStatusBadge(transaction.status)}
      </div>
    </div>
  )
}

export default function TransactionsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Transações</h1>
          <p className="text-muted-foreground">
            Gerencie todas as suas receitas e despesas
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline">
            <Upload className="h-4 w-4 mr-2" />
            Importar
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Nova Transação
          </Button>
        </div>
      </div>

      {/* Filtros e busca */}
      <Card>
        <CardHeader>
          <CardTitle>Filtros</CardTitle>
          <CardDescription>
            Use os filtros abaixo para encontrar transações específicas
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Buscar transações..." className="pl-9" />
            </div>
            
            <Button variant="outline" className="justify-start">
              <Calendar className="h-4 w-4 mr-2" />
              Período
            </Button>
            
            <Button variant="outline" className="justify-start">
              <Tag className="h-4 w-4 mr-2" />
              Categoria
            </Button>
            
            <Button variant="outline" className="justify-start">
              <DollarSign className="h-4 w-4 mr-2" />
              Conta
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Resumo */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Receitas</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ 6.200,00</div>
            <p className="text-xs text-muted-foreground">
              +12% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Despesas</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">R$ 1.411,30</div>
            <p className="text-xs text-muted-foreground">
              -5% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo do Período</CardTitle>
            <ArrowUpDown className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">R$ 4.788,70</div>
            <p className="text-xs text-muted-foreground">
              Economia de 77% da receita
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Lista de transações */}
      <Card>
        <CardHeader>
          <CardTitle>Transações Recentes</CardTitle>
          <CardDescription>
            Suas últimas movimentações financeiras
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {mockTransactions.map((transaction) => (
            <TransactionRow key={transaction.id} transaction={transaction} />
          ))}
          
          <div className="flex items-center justify-center pt-4">
            <Button variant="outline">
              Carregar mais transações
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
