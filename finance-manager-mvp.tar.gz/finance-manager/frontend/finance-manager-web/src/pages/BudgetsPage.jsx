import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Plus, Target, AlertTriangle, CheckCircle, Clock } from 'lucide-react'

const mockBudgets = [
  {
    id: 1,
    categoria: 'Alimentação',
    planejado: 800,
    realizado: 1050,
    percentual: 131,
    status: 'exceeded',
    cor: '#ef4444'
  },
  {
    id: 2,
    categoria: 'Moradia',
    planejado: 1500,
    realizado: 1740,
    percentual: 116,
    status: 'exceeded',
    cor: '#f97316'
  },
  {
    id: 3,
    categoria: 'Transporte',
    planejado: 400,
    realizado: 320,
    percentual: 80,
    status: 'warning',
    cor: '#3b82f6'
  },
  {
    id: 4,
    categoria: 'Saúde',
    planejado: 300,
    realizado: 180,
    percentual: 60,
    status: 'good',
    cor: '#06b6d4'
  },
  {
    id: 5,
    categoria: 'Lazer',
    planejado: 500,
    realizado: 420,
    percentual: 84,
    status: 'warning',
    cor: '#8b5cf6'
  },
  {
    id: 6,
    categoria: 'Educação',
    planejado: 200,
    realizado: 150,
    percentual: 75,
    status: 'good',
    cor: '#ec4899'
  }
]

function BudgetCard({ budget }) {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'exceeded':
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      case 'warning':
        return <Clock className="h-4 w-4 text-yellow-500" />
      case 'good':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      default:
        return <Target className="h-4 w-4 text-gray-500" />
    }
  }

  const getStatusBadge = (status, percentual) => {
    if (status === 'exceeded') {
      return <Badge variant="destructive">Excedido</Badge>
    } else if (status === 'warning') {
      return <Badge variant="secondary">Atenção</Badge>
    } else {
      return <Badge variant="outline">No limite</Badge>
    }
  }

  const getProgressColor = (percentual) => {
    if (percentual >= 100) return 'bg-red-500'
    if (percentual >= 80) return 'bg-yellow-500'
    return 'bg-green-500'
  }

  const restante = budget.planejado - budget.realizado

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-3">
          <div 
            className="p-2 rounded-lg text-white"
            style={{ backgroundColor: budget.cor }}
          >
            <Target className="h-4 w-4" />
          </div>
          <div>
            <CardTitle className="text-base">{budget.categoria}</CardTitle>
            <CardDescription>Orçamento mensal</CardDescription>
          </div>
        </div>
        
        {getStatusIcon(budget.status)}
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Progresso</span>
              {getStatusBadge(budget.status, budget.percentual)}
            </div>
            
            <div className="relative mb-2">
              <Progress value={Math.min(budget.percentual, 100)} className="h-3" />
              <div 
                className={`absolute top-0 left-0 h-3 rounded-full transition-all ${getProgressColor(budget.percentual)}`}
                style={{ width: `${Math.min(budget.percentual, 100)}%` }}
              />
            </div>
            
            <div className="flex justify-between text-sm">
              <span>{budget.percentual}% utilizado</span>
              <span className="font-medium">{budget.percentual}%</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Realizado</div>
              <div className="font-bold text-lg">
                R$ {budget.realizado.toLocaleString()}
              </div>
            </div>
            <div>
              <div className="text-muted-foreground">Planejado</div>
              <div className="font-bold text-lg">
                R$ {budget.planejado.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="pt-2 border-t">
            <div className="text-sm text-muted-foreground">
              {restante >= 0 ? 'Restante' : 'Excesso'}
            </div>
            <div className={`font-bold ${restante >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              R$ {Math.abs(restante).toLocaleString()}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" size="sm" className="flex-1">
              Ajustar
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              Detalhes
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function BudgetsPage() {
  const totalPlanejado = mockBudgets.reduce((total, budget) => total + budget.planejado, 0)
  const totalRealizado = mockBudgets.reduce((total, budget) => total + budget.realizado, 0)
  const percentualGeral = (totalRealizado / totalPlanejado) * 100

  const orcamentosExcedidos = mockBudgets.filter(b => b.status === 'exceeded').length
  const orcamentosAtencao = mockBudgets.filter(b => b.status === 'warning').length
  const orcamentosOk = mockBudgets.filter(b => b.status === 'good').length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Orçamentos</h1>
          <p className="text-muted-foreground">
            Defina e acompanhe suas metas de gastos mensais
          </p>
        </div>
        
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Novo Orçamento
        </Button>
      </div>

      {/* Resumo Geral */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Planejado</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {totalPlanejado.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Meta para este mês
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Realizado</CardTitle>
            <Target className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              R$ {totalRealizado.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground">
              Gasto até agora
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Percentual Geral</CardTitle>
            <Target className={`h-4 w-4 ${percentualGeral > 100 ? 'text-red-600' : percentualGeral > 80 ? 'text-yellow-600' : 'text-green-600'}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${percentualGeral > 100 ? 'text-red-600' : percentualGeral > 80 ? 'text-yellow-600' : 'text-green-600'}`}>
              {percentualGeral.toFixed(1)}%
            </div>
            <p className="text-xs text-muted-foreground">
              Do orçamento total
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Status Geral</CardTitle>
            <Target className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              <div className="flex justify-between text-sm">
                <span className="text-green-600">{orcamentosOk} OK</span>
                <span className="text-yellow-600">{orcamentosAtencao} Atenção</span>
                <span className="text-red-600">{orcamentosExcedidos} Excedidos</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progresso Geral */}
      <Card>
        <CardHeader>
          <CardTitle>Progresso Geral do Mês</CardTitle>
          <CardDescription>
            Acompanhe como está o cumprimento dos seus orçamentos
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="relative">
              <Progress value={Math.min(percentualGeral, 100)} className="h-4" />
              <div 
                className={`absolute top-0 left-0 h-4 rounded-full transition-all ${
                  percentualGeral >= 100 ? 'bg-red-500' : 
                  percentualGeral >= 80 ? 'bg-yellow-500' : 'bg-green-500'
                }`}
                style={{ width: `${Math.min(percentualGeral, 100)}%` }}
              />
            </div>
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>R$ 0</span>
              <span>R$ {totalPlanejado.toLocaleString()} (Meta)</span>
            </div>
            <div className="text-center">
              <span className="text-lg font-bold">
                R$ {(totalPlanejado - totalRealizado).toLocaleString()}
              </span>
              <span className="text-muted-foreground ml-2">
                {totalRealizado > totalPlanejado ? 'acima do orçamento' : 'restante no orçamento'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Orçamentos */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Orçamentos por Categoria</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {mockBudgets.map((budget) => (
            <BudgetCard key={budget.id} budget={budget} />
          ))}
        </div>
      </div>
    </div>
  )
}
