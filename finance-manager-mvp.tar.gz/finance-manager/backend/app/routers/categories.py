from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.category import Category
from app.schemas.category import CategoryCreate, CategoryUpdate, CategoryResponse, CategoryListResponse

router = APIRouter()

@router.get("/", response_model=CategoryListResponse)
async def list_categories(
    skip: int = 0,
    limit: int = 100,
    tipo: Optional[str] = None,
    parent_id: Optional[str] = None,
    ativo: Optional[bool] = None,
    search: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar categorias do usuário com filtros opcionais"""
    query = db.query(Category).filter(Category.user_id == current_user.id)
    
    # Aplicar filtros
    if tipo:
        query = query.filter(Category.tipo == tipo)
    
    if parent_id:
        query = query.filter(Category.parent_id == parent_id)
    elif parent_id is None:
        # Se não especificado, mostrar apenas categorias raiz
        query = query.filter(Category.parent_id.is_(None))
    
    if ativo is not None:
        query = query.filter(Category.ativo == ativo)
    
    if search:
        query = query.filter(
            or_(
                Category.nome.ilike(f"%{search}%"),
                Category.descricao.ilike(f"%{search}%")
            )
        )
    
    # Contar total
    total = query.count()
    
    # Aplicar paginação e ordenação
    categories = query.order_by(Category.nome).offset(skip).limit(limit).all()
    
    return CategoryListResponse(
        categories=categories,
        total=total,
        skip=skip,
        limit=limit
    )

@router.post("/", response_model=CategoryResponse, status_code=status.HTTP_201_CREATED)
async def create_category(
    category_data: CategoryCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Criar nova categoria"""
    # Verificar se já existe categoria com mesmo nome no mesmo nível
    existing = db.query(Category).filter(
        and_(
            Category.user_id == current_user.id,
            Category.nome == category_data.nome,
            Category.parent_id == category_data.parent_id
        )
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Já existe uma categoria com este nome no mesmo nível"
        )
    
    # Verificar se categoria pai existe (se especificada)
    if category_data.parent_id:
        parent = db.query(Category).filter(
            and_(
                Category.id == category_data.parent_id,
                Category.user_id == current_user.id
            )
        ).first()
        
        if not parent:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Categoria pai não encontrada"
            )
        
        # Verificar se tipos são compatíveis
        if parent.tipo != category_data.tipo:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Tipo da subcategoria deve ser igual ao da categoria pai"
            )
    
    # Criar categoria
    category = Category(
        **category_data.model_dump(),
        user_id=current_user.id
    )
    
    db.add(category)
    db.commit()
    db.refresh(category)
    
    return category

@router.get("/{category_id}", response_model=CategoryResponse)
async def get_category(
    category_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter categoria específica"""
    category = db.query(Category).filter(
        and_(
            Category.id == category_id,
            Category.user_id == current_user.id
        )
    ).first()
    
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria não encontrada"
        )
    
    return category

@router.put("/{category_id}", response_model=CategoryResponse)
async def update_category(
    category_id: str,
    category_data: CategoryUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Atualizar categoria"""
    category = db.query(Category).filter(
        and_(
            Category.id == category_id,
            Category.user_id == current_user.id
        )
    ).first()
    
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria não encontrada"
        )
    
    # Verificar nome duplicado (se alterado)
    if category_data.nome and category_data.nome != category.nome:
        existing = db.query(Category).filter(
            and_(
                Category.user_id == current_user.id,
                Category.nome == category_data.nome,
                Category.parent_id == category.parent_id,
                Category.id != category_id
            )
        ).first()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Já existe uma categoria com este nome no mesmo nível"
            )
    
    # Atualizar campos
    update_data = category_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(category, field, value)
    
    db.commit()
    db.refresh(category)
    
    return category

@router.delete("/{category_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_category(
    category_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Excluir categoria (soft delete)"""
    category = db.query(Category).filter(
        and_(
            Category.id == category_id,
            Category.user_id == current_user.id
        )
    ).first()
    
    if not category:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria não encontrada"
        )
    
    # Verificar se há subcategorias
    subcategories = db.query(Category).filter(Category.parent_id == category_id).first()
    if subcategories:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível excluir categoria que possui subcategorias"
        )
    
    # Verificar se há transações vinculadas
    from app.models.transaction import Transaction
    has_transactions = db.query(Transaction).filter(
        Transaction.categoria_id == category_id
    ).first()
    
    if has_transactions:
        # Soft delete - apenas desativar
        category.ativo = False
        db.commit()
    else:
        # Hard delete se não há transações
        db.delete(category)
        db.commit()

@router.get("/{category_id}/subcategories", response_model=List[CategoryResponse])
async def get_subcategories(
    category_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter subcategorias de uma categoria"""
    # Verificar se categoria pai existe
    parent = db.query(Category).filter(
        and_(
            Category.id == category_id,
            Category.user_id == current_user.id
        )
    ).first()
    
    if not parent:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Categoria não encontrada"
        )
    
    # Buscar subcategorias
    subcategories = db.query(Category).filter(
        and_(
            Category.parent_id == category_id,
            Category.user_id == current_user.id
        )
    ).order_by(Category.nome).all()
    
    return subcategories

@router.get("/tree/{tipo}")
async def get_category_tree(
    tipo: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter árvore hierárquica de categorias"""
    if tipo not in ['income', 'expense']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Tipo deve ser 'income' ou 'expense'"
        )
    
    # Buscar todas as categorias do tipo
    categories = db.query(Category).filter(
        and_(
            Category.user_id == current_user.id,
            Category.tipo == tipo,
            Category.ativo == True
        )
    ).order_by(Category.nome).all()
    
    # Construir árvore
    def build_tree(parent_id=None):
        tree = []
        for cat in categories:
            if cat.parent_id == parent_id:
                node = {
                    "id": str(cat.id),
                    "nome": cat.nome,
                    "cor": cat.cor,
                    "icone": cat.icone,
                    "descricao": cat.descricao,
                    "children": build_tree(cat.id)
                }
                tree.append(node)
        return tree
    
    return build_tree()
