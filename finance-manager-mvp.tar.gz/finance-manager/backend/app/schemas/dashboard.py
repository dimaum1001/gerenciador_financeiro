"""
Schemas Pydantic para Dashboard e Relatórios
"""

import uuid
from datetime import date
from decimal import Decimal
from typing import List, Optional, Dict, Any

from pydantic import BaseModel, Field, ConfigDict


class DashboardCard(BaseModel):
    """Schema para cards do dashboard"""
    titulo: str
    valor: Decimal
    valor_formatado: str
    variacao: Optional[Decimal] = None
    variacao_percentual: Optional[float] = None
    tendencia: Optional[str] = None  # "up", "down", "stable"
    cor: Optional[str] = None
    icone: Optional[str] = None
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "titulo": "Saldo Total",
                "valor": 15750.50,
                "valor_formatado": "R$ 15.750,50",
                "variacao": 1250.00,
                "variacao_percentual": 8.6,
                "tendencia": "up",
                "cor": "#10b981",
                "icone": "trending-up"
            }
        }
    )


class FluxoCaixaItem(BaseModel):
    """Schema para item do fluxo de caixa"""
    periodo: str  # "2024-01" ou "Jan/24"
    receitas: Decimal
    despesas: Decimal
    saldo: Decimal
    saldo_acumulado: Decimal
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "periodo": "Jan/24",
                "receitas": 5000.00,
                "despesas": 3250.00,
                "saldo": 1750.00,
                "saldo_acumulado": 15750.50
            }
        }
    )


class CategoriaGasto(BaseModel):
    """Schema para gastos por categoria"""
    category_id: uuid.UUID
    nome: str
    valor: Decimal
    valor_formatado: str
    percentual: float
    cor: Optional[str] = None
    icone: Optional[str] = None
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "category_id": "123e4567-e89b-12d3-a456-426614174000",
                "nome": "Alimentação",
                "valor": 850.00,
                "valor_formatado": "R$ 850,00",
                "percentual": 26.2,
                "cor": "#ef4444",
                "icone": "utensils"
            }
        }
    )


class ProximoVencimento(BaseModel):
    """Schema para próximos vencimentos"""
    transaction_id: uuid.UUID
    descricao: str
    valor: Decimal
    valor_formatado: str
    data_vencimento: date
    dias_restantes: int
    categoria: Optional[str] = None
    conta: str
    status: str
    cor_status: str
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "transaction_id": "123e4567-e89b-12d3-a456-426614174000",
                "descricao": "Cartão de Crédito",
                "valor": 1250.00,
                "valor_formatado": "R$ 1.250,00",
                "data_vencimento": "2024-01-15",
                "dias_restantes": 3,
                "categoria": "Cartão",
                "conta": "Nubank",
                "status": "pending",
                "cor_status": "#f59e0b"
            }
        }
    )


class SaldoConta(BaseModel):
    """Schema para saldo por conta"""
    account_id: uuid.UUID
    nome: str
    tipo: str
    saldo: Decimal
    saldo_formatado: str
    percentual_do_total: float
    cor: Optional[str] = None
    icone: Optional[str] = None
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "account_id": "123e4567-e89b-12d3-a456-426614174000",
                "nome": "Conta Corrente",
                "tipo": "checking",
                "saldo": 8500.00,
                "saldo_formatado": "R$ 8.500,00",
                "percentual_do_total": 54.0,
                "cor": "#3b82f6",
                "icone": "building-bank"
            }
        }
    )


class DashboardOverview(BaseModel):
    """Schema para visão geral do dashboard"""
    # Cards principais
    saldo_total: DashboardCard
    receitas_mes: DashboardCard
    despesas_mes: DashboardCard
    saldo_mes: DashboardCard
    
    # Gráficos e listas
    fluxo_caixa: List[FluxoCaixaItem]
    gastos_por_categoria: List[CategoriaGasto]
    proximos_vencimentos: List[ProximoVencimento]
    saldos_por_conta: List[SaldoConta]
    
    # Metadados
    periodo_referencia: str
    ultima_atualizacao: str
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "saldo_total": {
                    "titulo": "Saldo Total",
                    "valor": 15750.50,
                    "valor_formatado": "R$ 15.750,50",
                    "tendencia": "up"
                },
                "receitas_mes": {
                    "titulo": "Receitas do Mês",
                    "valor": 5000.00,
                    "valor_formatado": "R$ 5.000,00"
                },
                "periodo_referencia": "Janeiro 2024",
                "ultima_atualizacao": "2024-01-15T10:30:00Z"
            }
        }
    )


class RelatorioFinanceiro(BaseModel):
    """Schema para relatório financeiro"""
    periodo_inicio: date
    periodo_fim: date
    total_receitas: Decimal
    total_despesas: Decimal
    saldo_periodo: Decimal
    receitas_por_categoria: List[CategoriaGasto]
    despesas_por_categoria: List[CategoriaGasto]
    movimentacao_por_conta: List[Dict[str, Any]]
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "periodo_inicio": "2024-01-01",
                "periodo_fim": "2024-01-31",
                "total_receitas": 5000.00,
                "total_despesas": 3250.00,
                "saldo_periodo": 1750.00,
                "receitas_por_categoria": [],
                "despesas_por_categoria": [],
                "movimentacao_por_conta": []
            }
        }
    )


class DRESimplificado(BaseModel):
    """Schema para DRE simplificado"""
    periodo: str
    receitas_operacionais: Decimal
    custos_produtos: Decimal
    lucro_bruto: Decimal
    despesas_operacionais: Decimal
    lucro_operacional: Decimal
    outras_receitas: Decimal
    outras_despesas: Decimal
    lucro_liquido: Decimal
    margem_bruta: float
    margem_operacional: float
    margem_liquida: float
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "periodo": "Janeiro 2024",
                "receitas_operacionais": 5000.00,
                "custos_produtos": 0.00,
                "lucro_bruto": 5000.00,
                "despesas_operacionais": 3250.00,
                "lucro_operacional": 1750.00,
                "outras_receitas": 0.00,
                "outras_despesas": 0.00,
                "lucro_liquido": 1750.00,
                "margem_bruta": 100.0,
                "margem_operacional": 35.0,
                "margem_liquida": 35.0
            }
        }
    )


class MetricasFinanceiras(BaseModel):
    """Schema para métricas financeiras"""
    liquidez_corrente: Optional[float] = None
    endividamento: Optional[float] = None
    rentabilidade: Optional[float] = None
    crescimento_receitas: Optional[float] = None
    ticket_medio: Optional[Decimal] = None
    frequencia_transacoes: Optional[float] = None
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "liquidez_corrente": 2.5,
                "endividamento": 15.0,
                "rentabilidade": 8.5,
                "crescimento_receitas": 12.0,
                "ticket_medio": 125.50,
                "frequencia_transacoes": 2.3
            }
        }
    )


class DashboardFilter(BaseModel):
    """Schema para filtros do dashboard"""
    year: Optional[int] = Field(None, ge=2000, le=2100)
    month: Optional[int] = Field(None, ge=1, le=12)
    account_ids: Optional[List[uuid.UUID]] = None
    category_ids: Optional[List[uuid.UUID]] = None
    include_transfers: bool = Field(default=True)
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "year": 2024,
                "month": 1,
                "include_transfers": True
            }
        }
    )
