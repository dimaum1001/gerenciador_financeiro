import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { 
  BarChart3, 
  Download, 
  Calendar, 
  TrendingUp, 
  TrendingDown,
  PieChart,
  LineChart
} from 'lucide-react'
import {
  BarChart,
  Bar,
  LineChart as RechartsLineChart,
  Line,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts'

// Dados mockados para relatórios
const mockData = {
  fluxoMensal: [
    { mes: 'Jan', receitas: 5000, despesas: 3200, saldo: 1800 },
    { mes: 'Fev', receitas: 5200, despesas: 3100, saldo: 2100 },
    { mes: 'Mar', receitas: 4900, despesas: 3400, saldo: 1500 },
    { mes: 'Abr', receitas: 5100, despesas: 3300, saldo: 1800 },
    { mes: 'Mai', receitas: 5300, despesas: 3150, saldo: 2150 },
    { mes: 'Jun', receitas: 5000, despesas: 3250, saldo: 1750 }
  ],
  
  categoriasDespesas: [
    { categoria: 'Alimentação', valor: 1050, percentual: 32.3, cor: '#ef4444' },
    { categoria: 'Moradia', valor: 1200, percentual: 36.9, cor: '#f97316' },
    { categoria: 'Transporte', valor: 380, percentual: 11.7, cor: '#3b82f6' },
    { categoria: 'Saúde', valor: 250, percentual: 7.7, cor: '#06b6d4' },
    { categoria: 'Lazer', valor: 370, percentual: 11.4, cor: '#8b5cf6' }
  ],
  
  evolucaoPatrimonio: [
    { mes: 'Jan', patrimonio: 45000 },
    { mes: 'Fev', patrimonio: 47100 },
    { mes: 'Mar', patrimonio: 48600 },
    { mes: 'Abr', patrimonio: 50400 },
    { mes: 'Mai', patrimonio: 52550 },
    { mes: 'Jun', patrimonio: 54300 }
  ],
  
  comparativoAnual: [
    { categoria: 'Alimentação', ano2023: 9600, ano2024: 10200 },
    { categoria: 'Moradia', ano2023: 14400, ano2024: 15600 },
    { categoria: 'Transporte', ano2023: 4200, ano2024: 3800 },
    { categoria: 'Saúde', ano2023: 2800, ano2024: 3200 },
    { categoria: 'Lazer', ano2023: 4800, ano2024: 5200 }
  ]
}

function FluxoCaixaReport() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Fluxo de Caixa Mensal</CardTitle>
        <CardDescription>
          Evolução das receitas, despesas e saldo nos últimos 6 meses
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <RechartsLineChart data={mockData.fluxoMensal}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="mes" />
            <YAxis />
            <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="receitas" 
              stroke="#10b981" 
              strokeWidth={3}
              name="Receitas"
            />
            <Line 
              type="monotone" 
              dataKey="despesas" 
              stroke="#ef4444" 
              strokeWidth={3}
              name="Despesas"
            />
            <Line 
              type="monotone" 
              dataKey="saldo" 
              stroke="#3b82f6" 
              strokeWidth={3}
              name="Saldo"
            />
          </RechartsLineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

function CategoriasReport() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Distribuição de Despesas</CardTitle>
          <CardDescription>
            Gastos por categoria no mês atual
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <RechartsPieChart>
              <Pie
                data={mockData.categoriasDespesas}
                cx="50%"
                cy="50%"
                outerRadius={100}
                dataKey="valor"
                label={({ categoria, percentual }) => `${categoria} (${percentual}%)`}
              >
                {mockData.categoriasDespesas.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.cor} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
            </RechartsPieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Ranking de Gastos</CardTitle>
          <CardDescription>
            Categorias que mais consomem seu orçamento
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockData.categoriasDespesas
              .sort((a, b) => b.valor - a.valor)
              .map((categoria, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-lg font-bold text-muted-foreground">
                      #{index + 1}
                    </div>
                    <div 
                      className="w-4 h-4 rounded-full"
                      style={{ backgroundColor: categoria.cor }}
                    />
                    <span className="font-medium">{categoria.categoria}</span>
                  </div>
                  <div className="text-right">
                    <div className="font-bold">
                      R$ {categoria.valor.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {categoria.percentual}%
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function PatrimonioReport() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Evolução do Patrimônio</CardTitle>
        <CardDescription>
          Crescimento do patrimônio líquido ao longo do tempo
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <RechartsLineChart data={mockData.evolucaoPatrimonio}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="mes" />
            <YAxis />
            <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
            <Line 
              type="monotone" 
              dataKey="patrimonio" 
              stroke="#10b981" 
              strokeWidth={4}
              dot={{ fill: '#10b981', strokeWidth: 2, r: 6 }}
              name="Patrimônio"
            />
          </RechartsLineChart>
        </ResponsiveContainer>
        
        <div className="mt-4 grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-sm text-muted-foreground">Patrimônio Inicial</div>
            <div className="text-lg font-bold">R$ 45.000</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Patrimônio Atual</div>
            <div className="text-lg font-bold text-green-600">R$ 54.300</div>
          </div>
          <div>
            <div className="text-sm text-muted-foreground">Crescimento</div>
            <div className="text-lg font-bold text-blue-600">+20.7%</div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function ComparativoReport() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Comparativo Anual</CardTitle>
        <CardDescription>
          Comparação de gastos entre 2023 e 2024 por categoria
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <BarChart data={mockData.comparativoAnual}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="categoria" />
            <YAxis />
            <Tooltip formatter={(value) => `R$ ${value.toLocaleString()}`} />
            <Legend />
            <Bar dataKey="ano2023" fill="#94a3b8" name="2023" />
            <Bar dataKey="ano2024" fill="#3b82f6" name="2024" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

export default function ReportsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Relatórios</h1>
          <p className="text-muted-foreground">
            Análises detalhadas das suas finanças com gráficos e insights
          </p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Período
          </Button>
          <Button>
            <Download className="h-4 w-4 mr-2" />
            Exportar PDF
          </Button>
        </div>
      </div>

      {/* Cards de resumo */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Receita Média</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">R$ 5.083</div>
            <p className="text-xs text-muted-foreground">
              +2,1% vs período anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Despesa Média</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">R$ 3.233</div>
            <p className="text-xs text-muted-foreground">
              -1,8% vs período anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Taxa de Poupança</CardTitle>
            <PieChart className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">36,4%</div>
            <p className="text-xs text-muted-foreground">
              Da receita é poupada
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Crescimento</CardTitle>
            <LineChart className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">+20,7%</div>
            <p className="text-xs text-muted-foreground">
              Crescimento patrimonial
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs com diferentes relatórios */}
      <Tabs defaultValue="fluxo" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="fluxo">Fluxo de Caixa</TabsTrigger>
          <TabsTrigger value="categorias">Por Categoria</TabsTrigger>
          <TabsTrigger value="patrimonio">Patrimônio</TabsTrigger>
          <TabsTrigger value="comparativo">Comparativo</TabsTrigger>
        </TabsList>
        
        <TabsContent value="fluxo" className="space-y-4">
          <FluxoCaixaReport />
        </TabsContent>
        
        <TabsContent value="categorias" className="space-y-4">
          <CategoriasReport />
        </TabsContent>
        
        <TabsContent value="patrimonio" className="space-y-4">
          <PatrimonioReport />
        </TabsContent>
        
        <TabsContent value="comparativo" className="space-y-4">
          <ComparativoReport />
        </TabsContent>
      </Tabs>
    </div>
  )
}
