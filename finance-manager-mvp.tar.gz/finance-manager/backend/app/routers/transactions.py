from typing import List, Optional
from datetime import datetime, date
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import and_, or_, desc, func, extract

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.transaction import Transaction
from app.models.account import Account
from app.models.category import Category
from app.schemas.transaction import (
    TransactionCreate, TransactionUpdate, TransactionResponse, 
    TransactionListResponse, TransactionSummary
)

router = APIRouter()

@router.get("/", response_model=TransactionListResponse)
async def list_transactions(
    skip: int = 0,
    limit: int = 50,
    tipo: Optional[str] = None,
    categoria_id: Optional[str] = None,
    conta_origem_id: Optional[str] = None,
    conta_destino_id: Optional[str] = None,
    status: Optional[str] = None,
    data_inicio: Optional[date] = None,
    data_fim: Optional[date] = None,
    valor_min: Optional[float] = None,
    valor_max: Optional[float] = None,
    search: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar transações do usuário com filtros avançados"""
    query = db.query(Transaction).options(
        joinedload(Transaction.categoria),
        joinedload(Transaction.conta_origem),
        joinedload(Transaction.conta_destino)
    ).filter(Transaction.user_id == current_user.id)
    
    # Aplicar filtros
    if tipo:
        query = query.filter(Transaction.tipo == tipo)
    
    if categoria_id:
        query = query.filter(Transaction.categoria_id == categoria_id)
    
    if conta_origem_id:
        query = query.filter(Transaction.conta_origem_id == conta_origem_id)
    
    if conta_destino_id:
        query = query.filter(Transaction.conta_destino_id == conta_destino_id)
    
    if status:
        query = query.filter(Transaction.status == status)
    
    if data_inicio:
        query = query.filter(Transaction.data >= data_inicio)
    
    if data_fim:
        query = query.filter(Transaction.data <= data_fim)
    
    if valor_min is not None:
        query = query.filter(Transaction.valor >= valor_min)
    
    if valor_max is not None:
        query = query.filter(Transaction.valor <= valor_max)
    
    if search:
        query = query.filter(
            or_(
                Transaction.descricao.ilike(f"%{search}%"),
                Transaction.observacoes.ilike(f"%{search}%")
            )
        )
    
    # Contar total
    total = query.count()
    
    # Aplicar paginação e ordenação
    transactions = query.order_by(desc(Transaction.data), desc(Transaction.created_at)).offset(skip).limit(limit).all()
    
    return TransactionListResponse(
        transactions=transactions,
        total=total,
        skip=skip,
        limit=limit
    )

@router.post("/", response_model=TransactionResponse, status_code=status.HTTP_201_CREATED)
async def create_transaction(
    transaction_data: TransactionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Criar nova transação"""
    # Validar contas
    if transaction_data.conta_origem_id:
        conta_origem = db.query(Account).filter(
            and_(
                Account.id == transaction_data.conta_origem_id,
                Account.user_id == current_user.id
            )
        ).first()
        if not conta_origem:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Conta de origem não encontrada"
            )
    
    if transaction_data.conta_destino_id:
        conta_destino = db.query(Account).filter(
            and_(
                Account.id == transaction_data.conta_destino_id,
                Account.user_id == current_user.id
            )
        ).first()
        if not conta_destino:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Conta de destino não encontrada"
            )
    
    # Validar categoria
    if transaction_data.categoria_id:
        categoria = db.query(Category).filter(
            and_(
                Category.id == transaction_data.categoria_id,
                Category.user_id == current_user.id
            )
        ).first()
        if not categoria:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Categoria não encontrada"
            )
    
    # Criar transação
    transaction = Transaction(
        **transaction_data.model_dump(),
        user_id=current_user.id
    )
    
    db.add(transaction)
    db.commit()
    db.refresh(transaction)
    
    # Atualizar saldos das contas
    await _update_account_balances(transaction, db)
    
    return transaction

@router.get("/{transaction_id}", response_model=TransactionResponse)
async def get_transaction(
    transaction_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter transação específica"""
    transaction = db.query(Transaction).options(
        joinedload(Transaction.categoria),
        joinedload(Transaction.conta_origem),
        joinedload(Transaction.conta_destino)
    ).filter(
        and_(
            Transaction.id == transaction_id,
            Transaction.user_id == current_user.id
        )
    ).first()
    
    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transação não encontrada"
        )
    
    return transaction

@router.put("/{transaction_id}", response_model=TransactionResponse)
async def update_transaction(
    transaction_id: str,
    transaction_data: TransactionUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Atualizar transação"""
    transaction = db.query(Transaction).filter(
        and_(
            Transaction.id == transaction_id,
            Transaction.user_id == current_user.id
        )
    ).first()
    
    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transação não encontrada"
        )
    
    # Reverter saldos antigos
    await _revert_account_balances(transaction, db)
    
    # Atualizar campos
    update_data = transaction_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(transaction, field, value)
    
    db.commit()
    db.refresh(transaction)
    
    # Aplicar novos saldos
    await _update_account_balances(transaction, db)
    
    return transaction

@router.delete("/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_transaction(
    transaction_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Excluir transação"""
    transaction = db.query(Transaction).filter(
        and_(
            Transaction.id == transaction_id,
            Transaction.user_id == current_user.id
        )
    ).first()
    
    if not transaction:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Transação não encontrada"
        )
    
    # Reverter saldos
    await _revert_account_balances(transaction, db)
    
    # Excluir transação
    db.delete(transaction)
    db.commit()

@router.get("/summary/monthly")
async def get_monthly_summary(
    year: int = Query(default=datetime.now().year),
    month: int = Query(default=datetime.now().month),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter resumo mensal de transações"""
    # Receitas
    receitas = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'income',
            extract('year', Transaction.data) == year,
            extract('month', Transaction.data) == month
        )
    ).scalar() or 0
    
    # Despesas
    despesas = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'expense',
            extract('year', Transaction.data) == year,
            extract('month', Transaction.data) == month
        )
    ).scalar() or 0
    
    # Transferências
    transferencias = db.query(func.sum(Transaction.valor)).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == 'transfer',
            extract('year', Transaction.data) == year,
            extract('month', Transaction.data) == month
        )
    ).scalar() or 0
    
    return {
        "year": year,
        "month": month,
        "receitas": float(receitas),
        "despesas": float(abs(despesas)),
        "transferencias": float(transferencias),
        "saldo": float(receitas + despesas),  # despesas já são negativas
        "economia": float(receitas + despesas) if receitas > 0 else 0
    }

@router.get("/summary/by-category")
async def get_summary_by_category(
    tipo: str = Query(..., regex="^(income|expense)$"),
    year: int = Query(default=datetime.now().year),
    month: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter resumo por categoria"""
    query = db.query(
        Category.nome.label('categoria'),
        Category.cor.label('cor'),
        func.sum(Transaction.valor).label('total'),
        func.count(Transaction.id).label('quantidade')
    ).join(
        Transaction, Transaction.categoria_id == Category.id
    ).filter(
        and_(
            Transaction.user_id == current_user.id,
            Transaction.tipo == tipo,
            extract('year', Transaction.data) == year
        )
    )
    
    if month:
        query = query.filter(extract('month', Transaction.data) == month)
    
    results = query.group_by(Category.id, Category.nome, Category.cor).all()
    
    total_geral = sum(float(r.total) for r in results)
    
    return [
        {
            "categoria": r.categoria,
            "cor": r.cor,
            "valor": float(abs(r.total)),
            "quantidade": r.quantidade,
            "percentual": (float(abs(r.total)) / total_geral * 100) if total_geral > 0 else 0
        }
        for r in results
    ]

async def _update_account_balances(transaction: Transaction, db: Session):
    """Atualizar saldos das contas após transação"""
    if transaction.tipo == 'income' and transaction.conta_destino_id:
        # Receita: adicionar ao saldo da conta destino
        conta = db.query(Account).filter(Account.id == transaction.conta_destino_id).first()
        if conta:
            conta.saldo_atual += transaction.valor
    
    elif transaction.tipo == 'expense' and transaction.conta_origem_id:
        # Despesa: subtrair do saldo da conta origem
        conta = db.query(Account).filter(Account.id == transaction.conta_origem_id).first()
        if conta:
            conta.saldo_atual += transaction.valor  # valor já é negativo
    
    elif transaction.tipo == 'transfer':
        # Transferência: subtrair da origem e adicionar ao destino
        if transaction.conta_origem_id:
            conta_origem = db.query(Account).filter(Account.id == transaction.conta_origem_id).first()
            if conta_origem:
                conta_origem.saldo_atual -= abs(transaction.valor)
        
        if transaction.conta_destino_id:
            conta_destino = db.query(Account).filter(Account.id == transaction.conta_destino_id).first()
            if conta_destino:
                conta_destino.saldo_atual += abs(transaction.valor)
    
    db.commit()

async def _revert_account_balances(transaction: Transaction, db: Session):
    """Reverter saldos das contas antes de atualizar/excluir transação"""
    if transaction.tipo == 'income' and transaction.conta_destino_id:
        conta = db.query(Account).filter(Account.id == transaction.conta_destino_id).first()
        if conta:
            conta.saldo_atual -= transaction.valor
    
    elif transaction.tipo == 'expense' and transaction.conta_origem_id:
        conta = db.query(Account).filter(Account.id == transaction.conta_origem_id).first()
        if conta:
            conta.saldo_atual -= transaction.valor  # valor já é negativo
    
    elif transaction.tipo == 'transfer':
        if transaction.conta_origem_id:
            conta_origem = db.query(Account).filter(Account.id == transaction.conta_origem_id).first()
            if conta_origem:
                conta_origem.saldo_atual += abs(transaction.valor)
        
        if transaction.conta_destino_id:
            conta_destino = db.query(Account).filter(Account.id == transaction.conta_destino_id).first()
            if conta_destino:
                conta_destino.saldo_atual -= abs(transaction.valor)
    
    db.commit()
