import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { 
  Plus, 
  Wallet, 
  CreditCard, 
  PiggyBank, 
  TrendingUp,
  Building,
  MoreHorizontal,
  Eye,
  EyeOff
} from 'lucide-react'

const mockAccounts = [
  {
    id: 1,
    nome: 'Conta Corrente BB',
    tipo: 'checking',
    banco: 'Banco do Brasil',
    saldo: 8500.00,
    limite: null,
    cor: '#3b82f6',
    icon: Building,
    ativo: true
  },
  {
    id: 2,
    nome: 'Poupança Caixa',
    tipo: 'savings',
    banco: 'Caixa Econômica',
    saldo: 15000.00,
    limite: null,
    cor: '#059669',
    icon: PiggyBank,
    ativo: true
  },
  {
    id: 3,
    nome: 'Cartão Nubank',
    tipo: 'credit',
    banco: 'Nubank',
    saldo: -1250.00,
    limite: 5000.00,
    cor: '#8b5cf6',
    icon: CreditCard,
    ativo: true
  },
  {
    id: 4,
    nome: 'Investimentos XP',
    tipo: 'investment',
    banco: 'XP Investimentos',
    saldo: 25000.00,
    limite: null,
    cor: '#f59e0b',
    icon: TrendingUp,
    ativo: true
  },
  {
    id: 5,
    nome: 'Carteira',
    tipo: 'cash',
    banco: null,
    saldo: 750.00,
    limite: null,
    cor: '#10b981',
    icon: Wallet,
    ativo: true
  }
]

function AccountCard({ account }) {
  const Icon = account.icon
  
  const getTypeLabel = (tipo) => {
    const labels = {
      checking: 'Conta Corrente',
      savings: 'Poupança',
      credit: 'Cartão de Crédito',
      investment: 'Investimentos',
      cash: 'Dinheiro'
    }
    return labels[tipo] || tipo
  }

  const formatSaldo = (saldo) => {
    const valor = Math.abs(saldo)
    const prefix = saldo < 0 ? '-' : ''
    return `${prefix}R$ ${valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`
  }

  const getSaldoColor = (saldo, tipo) => {
    if (tipo === 'credit') {
      return saldo < 0 ? 'text-red-600' : 'text-green-600'
    }
    return saldo >= 0 ? 'text-green-600' : 'text-red-600'
  }

  const getLimiteUtilizado = () => {
    if (account.tipo !== 'credit' || !account.limite) return null
    const utilizado = Math.abs(account.saldo)
    const percentual = (utilizado / account.limite) * 100
    return { utilizado, percentual }
  }

  const limiteInfo = getLimiteUtilizado()

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-3">
          <div 
            className="p-2 rounded-lg text-white"
            style={{ backgroundColor: account.cor }}
          >
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-base">{account.nome}</CardTitle>
            <CardDescription>{getTypeLabel(account.tipo)}</CardDescription>
          </div>
        </div>
        
        <Button variant="ghost" size="sm">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="text-sm text-muted-foreground mb-1">
              {account.tipo === 'credit' ? 'Fatura Atual' : 'Saldo'}
            </div>
            <div className={`text-2xl font-bold ${getSaldoColor(account.saldo, account.tipo)}`}>
              {formatSaldo(account.saldo)}
            </div>
          </div>

          {account.banco && (
            <div className="text-sm text-muted-foreground">
              {account.banco}
            </div>
          )}

          {limiteInfo && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Limite utilizado</span>
                <span>{limiteInfo.percentual.toFixed(1)}%</span>
              </div>
              <Progress value={limiteInfo.percentual} className="h-2" />
              <div className="text-xs text-muted-foreground">
                R$ {limiteInfo.utilizado.toLocaleString()} de R$ {account.limite.toLocaleString()}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button variant="outline" size="sm" className="flex-1">
              <Eye className="h-4 w-4 mr-1" />
              Ver
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              Editar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function AccountsPage() {
  const totalPatrimonio = mockAccounts
    .filter(acc => acc.tipo !== 'credit')
    .reduce((total, acc) => total + acc.saldo, 0)

  const totalDividas = mockAccounts
    .filter(acc => acc.tipo === 'credit' && acc.saldo < 0)
    .reduce((total, acc) => total + Math.abs(acc.saldo), 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Contas</h1>
          <p className="text-muted-foreground">
            Gerencie suas contas bancárias, cartões e investimentos
          </p>
        </div>
        
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nova Conta
        </Button>
      </div>

      {/* Resumo */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patrimônio Total</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              R$ {totalPatrimonio.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              +8,2% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Dívidas Totais</CardTitle>
            <CreditCard className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              R$ {totalDividas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              -12% em relação ao mês anterior
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Patrimônio Líquido</CardTitle>
            <Wallet className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              R$ {(totalPatrimonio - totalDividas).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              Patrimônio menos dívidas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Lista de contas */}
      <div>
        <h2 className="text-xl font-semibold mb-4">Suas Contas</h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {mockAccounts.map((account) => (
            <AccountCard key={account.id} account={account} />
          ))}
        </div>
      </div>
    </div>
  )
}
