from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_, desc

from app.core.deps import get_current_user, get_db
from app.models.user import User
from app.models.account import Account
from app.schemas.account import AccountCreate, AccountUpdate, AccountResponse, AccountListResponse

router = APIRouter()

@router.get("/", response_model=AccountListResponse)
async def list_accounts(
    skip: int = 0,
    limit: int = 100,
    tipo: Optional[str] = None,
    ativo: Optional[bool] = None,
    search: Optional[str] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Listar contas do usuário com filtros opcionais"""
    query = db.query(Account).filter(Account.user_id == current_user.id)
    
    # Aplicar filtros
    if tipo:
        query = query.filter(Account.tipo == tipo)
    
    if ativo is not None:
        query = query.filter(Account.ativo == ativo)
    
    if search:
        query = query.filter(
            or_(
                Account.nome.ilike(f"%{search}%"),
                Account.banco.ilike(f"%{search}%"),
                Account.descricao.ilike(f"%{search}%")
            )
        )
    
    # Contar total
    total = query.count()
    
    # Aplicar paginação e ordenação
    accounts = query.order_by(desc(Account.updated_at)).offset(skip).limit(limit).all()
    
    return AccountListResponse(
        accounts=accounts,
        total=total,
        skip=skip,
        limit=limit
    )

@router.post("/", response_model=AccountResponse, status_code=status.HTTP_201_CREATED)
async def create_account(
    account_data: AccountCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Criar nova conta"""
    # Verificar se já existe conta com mesmo nome
    existing = db.query(Account).filter(
        and_(
            Account.user_id == current_user.id,
            Account.nome == account_data.nome
        )
    ).first()
    
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Já existe uma conta com este nome"
        )
    
    # Criar conta
    account = Account(
        **account_data.model_dump(),
        user_id=current_user.id
    )
    
    db.add(account)
    db.commit()
    db.refresh(account)
    
    return account

@router.get("/{account_id}", response_model=AccountResponse)
async def get_account(
    account_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter conta específica"""
    account = db.query(Account).filter(
        and_(
            Account.id == account_id,
            Account.user_id == current_user.id
        )
    ).first()
    
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conta não encontrada"
        )
    
    return account

@router.put("/{account_id}", response_model=AccountResponse)
async def update_account(
    account_id: str,
    account_data: AccountUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Atualizar conta"""
    account = db.query(Account).filter(
        and_(
            Account.id == account_id,
            Account.user_id == current_user.id
        )
    ).first()
    
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conta não encontrada"
        )
    
    # Verificar nome duplicado (se alterado)
    if account_data.nome and account_data.nome != account.nome:
        existing = db.query(Account).filter(
            and_(
                Account.user_id == current_user.id,
                Account.nome == account_data.nome,
                Account.id != account_id
            )
        ).first()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Já existe uma conta com este nome"
            )
    
    # Atualizar campos
    update_data = account_data.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(account, field, value)
    
    db.commit()
    db.refresh(account)
    
    return account

@router.delete("/{account_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_account(
    account_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Excluir conta (soft delete)"""
    account = db.query(Account).filter(
        and_(
            Account.id == account_id,
            Account.user_id == current_user.id
        )
    ).first()
    
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conta não encontrada"
        )
    
    # Verificar se há transações vinculadas
    from app.models.transaction import Transaction
    has_transactions = db.query(Transaction).filter(
        or_(
            Transaction.conta_origem_id == account_id,
            Transaction.conta_destino_id == account_id
        )
    ).first()
    
    if has_transactions:
        # Soft delete - apenas desativar
        account.ativo = False
        db.commit()
    else:
        # Hard delete se não há transações
        db.delete(account)
        db.commit()

@router.get("/{account_id}/balance")
async def get_account_balance(
    account_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Obter saldo atual da conta"""
    account = db.query(Account).filter(
        and_(
            Account.id == account_id,
            Account.user_id == current_user.id
        )
    ).first()
    
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Conta não encontrada"
        )
    
    return {
        "account_id": account_id,
        "account_name": account.nome,
        "balance": account.saldo_atual,
        "currency": "BRL",
        "last_updated": account.updated_at
    }
