import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, Tag, TrendingUp, TrendingDown, MoreHorizontal } from 'lucide-react'

const mockCategories = [
  {
    id: 1,
    nome: 'Alimentação',
    tipo: 'expense',
    cor: '#ef4444',
    icon: '🍽️',
    subcategorias: [
      { nome: 'Supermercado', gastoMes: 650 },
      { nome: 'Restaurantes', gastoMes: 280 },
      { nome: 'Delivery', gastoMes: 120 }
    ],
    gastoMes: 1050,
    orcamento: 800
  },
  {
    id: 2,
    nome: 'Moradia',
    tipo: 'expense',
    cor: '#f97316',
    icon: '🏠',
    subcategorias: [
      { nome: 'Aluguel', gastoMes: 1200 },
      { nome: 'Condomínio', gastoMes: 350 },
      { nome: 'Energia', gastoMes: 125 },
      { nome: 'Água', gastoMes: 65 }
    ],
    gastoMes: 1740,
    orcamento: 1500
  },
  {
    id: 3,
    nome: 'Transporte',
    tipo: 'expense',
    cor: '#3b82f6',
    icon: '🚗',
    subcategorias: [
      { nome: 'Combustível', gastoMes: 280 },
      { nome: 'Uber/Taxi', gastoMes: 150 },
      { nome: 'Manutenção', gastoMes: 200 }
    ],
    gastoMes: 630,
    orcamento: 400
  },
  {
    id: 4,
    nome: 'Salário',
    tipo: 'income',
    cor: '#10b981',
    icon: '💰',
    subcategorias: [],
    receitaMes: 5000,
    meta: 5000
  },
  {
    id: 5,
    nome: 'Freelance',
    tipo: 'income',
    cor: '#059669',
    icon: '💼',
    subcategorias: [],
    receitaMes: 1200,
    meta: 1500
  }
]

function CategoryCard({ category }) {
  const isIncome = category.tipo === 'income'
  const valor = isIncome ? category.receitaMes : category.gastoMes
  const meta = isIncome ? category.meta : category.orcamento
  const percentual = meta ? (valor / meta) * 100 : 0
  
  const getStatusColor = () => {
    if (isIncome) {
      return percentual >= 100 ? 'text-green-600' : 'text-yellow-600'
    } else {
      if (percentual > 100) return 'text-red-600'
      if (percentual > 80) return 'text-yellow-600'
      return 'text-green-600'
    }
  }

  const getStatusText = () => {
    if (isIncome) {
      return percentual >= 100 ? 'Meta atingida' : 'Abaixo da meta'
    } else {
      if (percentual > 100) return 'Acima do orçamento'
      if (percentual > 80) return 'Próximo do limite'
      return 'Dentro do orçamento'
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center gap-3">
          <div 
            className="p-2 rounded-lg text-white text-lg"
            style={{ backgroundColor: category.cor }}
          >
            {category.icon}
          </div>
          <div>
            <CardTitle className="text-base">{category.nome}</CardTitle>
            <CardDescription>
              {isIncome ? 'Receita' : 'Despesa'} • {category.subcategorias.length} subcategorias
            </CardDescription>
          </div>
        </div>
        
        <Button variant="ghost" size="sm">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">
                {isIncome ? 'Receita do mês' : 'Gasto do mês'}
              </span>
              <Badge variant="outline" className={getStatusColor()}>
                {getStatusText()}
              </Badge>
            </div>
            <div className="text-2xl font-bold">
              R$ {valor.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            {meta && (
              <div className="text-sm text-muted-foreground">
                de R$ {meta.toLocaleString('pt-BR', { minimumFractionDigits: 2 })} {isIncome ? 'meta' : 'orçamento'}
              </div>
            )}
          </div>

          {category.subcategorias.length > 0 && (
            <div>
              <div className="text-sm font-medium mb-2">Subcategorias</div>
              <div className="space-y-1">
                {category.subcategorias.slice(0, 3).map((sub, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="text-muted-foreground">{sub.nome}</span>
                    <span>R$ {sub.gastoMes.toLocaleString()}</span>
                  </div>
                ))}
                {category.subcategorias.length > 3 && (
                  <div className="text-xs text-muted-foreground">
                    +{category.subcategorias.length - 3} mais
                  </div>
                )}
              </div>
            </div>
          )}

          <div className="flex gap-2 pt-2">
            <Button variant="outline" size="sm" className="flex-1">
              Ver detalhes
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              Editar
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export default function CategoriesPage() {
  const receitas = mockCategories.filter(cat => cat.tipo === 'income')
  const despesas = mockCategories.filter(cat => cat.tipo === 'expense')
  
  const totalReceitas = receitas.reduce((total, cat) => total + (cat.receitaMes || 0), 0)
  const totalDespesas = despesas.reduce((total, cat) => total + (cat.gastoMes || 0), 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Categorias</h1>
          <p className="text-muted-foreground">
            Organize suas transações por categorias e subcategorias
          </p>
        </div>
        
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Nova Categoria
        </Button>
      </div>

      {/* Resumo */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Receitas</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              R$ {totalReceitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              {receitas.length} categorias de receita
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Despesas</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              R$ {totalDespesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              {despesas.length} categorias de despesa
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Saldo Líquido</CardTitle>
            <Tag className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              R$ {(totalReceitas - totalDespesas).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
            <p className="text-xs text-muted-foreground">
              Receitas menos despesas
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Categorias de Receita */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="h-5 w-5 text-green-600" />
          Categorias de Receita
        </h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {receitas.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>

      {/* Categorias de Despesa */}
      <div>
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <TrendingDown className="h-5 w-5 text-red-600" />
          Categorias de Despesa
        </h2>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {despesas.map((category) => (
            <CategoryCard key={category.id} category={category} />
          ))}
        </div>
      </div>
    </div>
  )
}
